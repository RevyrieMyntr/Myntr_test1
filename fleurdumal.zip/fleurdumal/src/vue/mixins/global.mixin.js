export default {
  data () {
    return {
      env: process.env.NODE_ENV
    }
  }
}